// import React from "react";
// import Test from "./test";

// class Welcome extends React.Component {
 
//     constructor(props){
//         super(props);
//         this.state = {
//             name:this.props.name ,
//             place:this.props.place
           
//         }
//     }
//     testt(name){
//         this.setState({
//             ...this.state,
//                 name
//         });
//     }

//     render(){
//         return (<>
//             <h1>{this.state.name}</h1>
//             <button onClick={this.testt.bind(this,"Abin")}>Change Name</button>
//             <Test name={this.state.name} changeName = {this.testt.bind(this)}/>
//         </>);
//     }

// }
// import React,{useState} from "react"
// import Greet from "./test"

// function Welcome(){

//     const[name,setName]=useState('Bibin');

//     return(
//         <>
//         <h1>Welcome {name}</h1>
//             <Greet newname={setName}/>
//         </>
//     )
// }





// function Mycount(){
//     const [count, setCount] = useState(0);
//     return(
//         <>
// <button onClick={() => setCount(count + 1)}>Incriment </button><br></br>
// <h2>{count}</h2>
// <button onClick={() => setCount(count - 1)}>Decrement</button><br></br>

// </>
//     )
// }
// var count=0
// var start=()=>{
//     console.log("called")
//     count++
//     return count
//     setTimeout(start,1000)
    
// }

// function Stop(){
//     const[count, setCount] = useState(0);
// return(<>
        
// <button onClick={() => setCount(()=>start())}>Start</button><br></br>
// <h2>{count}</h2>
// <button onClick={() => setCount(count)}>Stop</button><br></br>
// <button onClick={() => setCount(0)}>Reset</button><br></br>
// </>

// )
// }


// export default Welcome
// export {Mycount,Stop}
