// import React from 'react';


// class Test extends React.Component {

//     constructor(props){
//         super(props)
//     }
//     render(){
//         return (<>
//             <h1>Test - {this.props.name}</h1>
//             <button onClick={()=>this.props.changeName("Benin")}>Change Name 2</button>
//         </>);
//     }

// }
// import Welcome from "./welcome";
// import React,{useState} from "react"


// function Greet(props){
//     return(<>
//         <h2>Have a nice day , </h2>
//         <button onClick={()=>props.newname("Ajin")}>Change Name</button><br></br>
//         </>
//     )
// }


// export default Greet;