
import logo from './logo.svg';
import './App.css';
import React,{useState} from 'react'
// import Welcome from './welcome';
// import {Mycount} from './welcome';
// import {Stop} from './welcome';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" /> */}
        {/* <Welcome />
        <Mycount/> */}
        {/* <Stop/ > */}
        <Index/>
        
        
        
        
       

      </header>
    </div>
  );
}

function Index(){

  const[log,setLog]=useState(false)  
  const[user,setUser]=useState(null)
  console.log(log)
  return(
    <>
  <Header user={user}/>
  <Container log={log} setLog={setLog} setUser={setUser}/>
  <Sidebar/>
  </>
  )
}


function Header(props){
  return(
    <>
    <h1>Welcome {props.user}</h1>
    <nav class="navbar navbar-expand-sm  navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>    
    </ul>
    
  </div> 
  
</nav>

    </>
  )
}



function Container(props){
  
  const[name,setName]=useState('null')
  const[pw,setPw]=useState('null')
  
  const checklog=()=>{
    if(name=='Bibin'&&pw==123){
      alert("Successfully Logged In")
        props.setLog(true)
        props.setUser(name)
        
      
    }
    else{
      alert("Incorrect Username or Password")
      
    }
  }
  const changelog=()=>{
    props.setLog(false)
  }
  console.log(name)
  console.log(props.log)
  return( <div>
  <h2>Container</h2>
  {!props.log?<div>
  <input type='text' class='form-control' required onKeyUp={(a)=>setName(a.target.value)} /><br></br>
  <input type='password' class='form-control' required onKeyUp={(b)=>setPw(b.target.value)} /><br></br>
  
  <button onClick={checklog} class='btn btn-primary'>Login</button>
  
  </div>:<button onClick={changelog} class='btn btn-'>Logout</button>}

  </div> )
  
}

function Sidebar(){
  return <div>
  <h2>Side Bar</h2></div> 
}


    
    
    
    
  
 

export default App;
