import React,{useState,useEffect} from "react";
import { Link } from "react-router-dom";
import axios from 'axios'

function Courselist(){
    const[course,setCourse]=useState([])
    useEffect(()=>{
        getCourse();
}
)

const getCourse=async()=>{

    const {data}=await axios.get('http://karka.academy/api/action.php?request=getCourses')
    setCourse(data.data)
    // console.log(course)
}
return(
    <>
    <div className="width">
        <ul className="text-center font card p-3 ">
            {course.map(item=><li className=" mt-3 bg-secondary card" key={item.id}><Link className="text-white text" to={`/course/${item.id}`}>{item.name}</Link></li>)}
        </ul>
    </div>
    </>
)

}
export default Courselist