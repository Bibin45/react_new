import React,{useState,useEffect,useContext} from "react";
import Header from "./Header";
import axios from 'axios'
import Footer from "./Footer";
import UserContext from '../store'

function Userlist(){
    const value= useContext(UserContext)
    
    useEffect(()=>{
        getUser();
    }
    )

const getUser=async()=>{

    const {data}=await axios.get('http://karka.academy/api/action.php?request=getAllMembers')
    value.setUser(data.data)
    // console.log(course)
}
return(
    <>
    <Header/>
    <div className="container font ">
    <h2 className="mt-3 text-primary font text-center card p-3">All User's are,</h2>
    <div className="width mt-3">
        <ul className="text-center font card p-3 ">
            {value.user.map(item=><li className=" mt-3 bg-secondary card text-white p-2" key={item.id}>{item.name}</li>)}
        </ul>
    </div>
    </div>
    <Footer/>
    </>
)

}
export default Userlist