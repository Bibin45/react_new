import React,{useState} from 'react'
import {
    BrowserRouter as Router,
    Routes,
    Route
}from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Course from './pages/Courses'
import Register from './pages/Register'
import UserContext from './store'
import Createcourse from './pages/Create'
import Userlist from './components/user_list'


function Mainroutes(){

    const[islog,setIslog]=useState(false)
    const[user,setUser]=useState([])
    const[loguser,setLoguser]=useState([])
    return(
        <UserContext.Provider value={{islog,setIslog,user,setUser,loguser,setLoguser}}>
            <Router>
                <Routes>
                    <Route path='/' exact element={<Login/>}/>
                    <Route path='/register' exact element={<Register/>}/>
                    <Route path='/home' exact element={<Home/>}/>
                    <Route path='/course/:id' element={<Course/>} />
                    <Route path='/create' element={<Createcourse/>} />
                    <Route path='/user' element={<Userlist/>} />
                </Routes>
            </Router>
        </UserContext.Provider>
    )
}


export default Mainroutes