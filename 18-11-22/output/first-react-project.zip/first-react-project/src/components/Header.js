import {useNavigate,Link} from 'react-router-dom'
import React,{useEffect,useContext} from 'react'
import UserContext from '../store'
function Header(){
    const value= useContext(UserContext)
    let log=localStorage.getItem('log')
    let navigate=useNavigate()
    
 
    const Logout=()=>{
        value.setIslog(false)
        localStorage.setItem('log',false)
        navigate('/')
        console.log(value.islog)
    }

    return(<>
<div className="container font ">
<nav className="navbar navbar-expand-lg  text-white d-flex justify-content-around border rounded bg-secondary">
<Link to='/home'>  <button className="nav-item mt-3 mb-3 btn btn-primary">Home</button></Link>
    <Link to='/create' className="nav-item text-white"><button className='btn btn-primary'> Create Course</button> </Link>
    <Link to='/user' className="nav-item text-white"><button className='btn btn-primary'> All User's</button> </Link>

    <button type='button' className="btn btn-warning text-white font align" onClick={Logout}>Logout</button>
    
</nav>
</div>

</>
    )
}

export default Header