import React,{useEffect,useContext} from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import {useNavigate,Link} from 'react-router-dom'
import Courselist from '../components/Course_list'
import Createcourse from './Create'
import UserContext from '../store'

function Home( ){
    let navigate=useNavigate()
    
const value= useContext(UserContext)
let log=localStorage.getItem('log')
    useEffect(()=>{
            if(value.islog||log===true) navigate('/home')
        },
        [value.islog]
    )
    
    return(
        <>
        <Header />
        <div className='container'>
            <h2 className='mt-5 mb-5 text-primary width font card text-center' >Welcome {value.loguser.name} </h2>
            <h3 className='font text-success m-5'>Our Courses Are,</h3>
        </div>
        <Courselist/>
        
        <Footer/>
        </>
    )
}


export default Home