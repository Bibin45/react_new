import {useState} from 'react'
import axios from 'axios'
import {useNavigate} from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'


function Createcourse(){
    let navigate=useNavigate()
    const[createcourse,setCreatecourse]=useState({
        request:'create_course',
        name:'',
        video_id:'',
        description:'',
        price:''
        })
console.log(createcourse)
        const Create=async()=>{
        
            const data =  await axios.post('https://karka.academy/api/action.php',JSON.stringify(createcourse))
            console.log(data)
            setCreatecourse({...Createcourse,name:'',video_id:'',description:'',price:''})
            navigate('/home')
            }

    return(
        <>
        <Header/>
        <div className=' text-center card width mt-5 mb-5 font p-2'>
            <h2 className='text-primary card font m-1 p-3'>Create Your Course</h2>
            <input className='form-control m-1' value={createcourse.name} onChange={(e)=>setCreatecourse({...createcourse,name:e.target.value})} placeholder="Enter Name"/>
            <input className='form-control m-1'value={createcourse.video_id} onChange={(e)=>setCreatecourse({...createcourse,video_id:e.target.value})}placeholder="Enter Video Id"/>
            <input className='form-control m-1'value={createcourse.description} onChange={(e)=>setCreatecourse({...createcourse,description:e.target.value})}placeholder="Enter Course Description"/>
            <input className='form-control m-1' value={createcourse.price}onChange={(e)=>setCreatecourse({...createcourse,price:e.target.value})} placeholder="Enter Course Price"/>
            <button className='btn btn-primary col btn-lg width' type="button" onClick={Create}>Create Course</button>
        </div>
        <Footer/>
        </>
    )

}
export default Createcourse