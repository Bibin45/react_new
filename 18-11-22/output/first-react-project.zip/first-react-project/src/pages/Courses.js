import React,{useState,useEffect,useContext} from "react";
import { useNavigate,Link,useParams } from "react-router-dom";
import axios from 'axios'
import Courselist from "../components/Course_list";
import Header from "../components/Header";
import Footer from "../components/Footer";
import UserContext from '../store'

function Course(){
        
const value= useContext(UserContext)
let log=localStorage.getItem('log')
    const params = useParams();
    // console.log(params)
const[details,setDetails]=useState({})
let navigate = useNavigate();

    useEffect(()=>{
            if(!value.islog&&!log) navigate('/')
            getCourseDetails(params.id);
    },
    [value.islog,params.id]
    )

    const getCourseDetails = async() => {
        const {data} = await axios.get(`http://karka.academy/api/action.php?request=getCourseDetails&id=${params.id}`)
        setDetails(data.data)  
    }


    return (
    <>
            <Header />
                <div className="row ">
                    <div  className='col-4  mt-5 mb-5'><Courselist />
                    </div>
                    <div className="col-6  mt-5 mb-5">
                        <div className="card  border  p-5">
                                <div className="row border border-warning rounded p-3 m-1">
                                    <h3 className="font text-secondary col">Course Name : </h3>
                                    <h4 className="col-5 font align text-secondary">{details.name}</h4>
                               </div>
                                <div className="row border border-warning rounded p-3 m-1">
                                    <h3 className="font text-secondary col">Course Description : </h3>
                                    <h4 className="col-5 font align text-secondary">{details.description}</h4>
                                </div> 
                                <div className="row border border-warning  rounded p-3 m-1">
                                    <h3 className="font text-secondary col">Course Price : </h3>
                                    <h4 className="col-5 font align text-secondary">₹ {details.price}</h4>
                                </div>
                        </div>
                        
                    </div>
                </div>
                
            
            <Footer/>

            
        </>
    )

}
export default Course