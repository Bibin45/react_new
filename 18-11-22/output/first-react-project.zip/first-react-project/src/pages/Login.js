import React,{useEffect, useState,useContext} from "react"
import axios from 'axios'
import {useNavigate} from 'react-router-dom'
import UserContext from '../store'


function Login(){
    
    const value= useContext(UserContext)
    let log=localStorage.getItem('log')
    
let navigate=useNavigate()


    useEffect(()=>{
        if(!value.islog&&!log===false) navigate('/')
    },[value.islog]
    )

    // useEffect(()=>{
    //     if(log===true)navigate('/home')
    // },
    // [value.islog]
        
    // )
    
    

    const[reqdata,setReqdata]=useState({
        request:'candidate_login',
          email:'',
          password:''
    })
    const Check=async()=>{
        
        const {data} =  await axios.post('http://karka.academy/api/action.php',JSON.stringify(reqdata))
        console.log(data)
        value.setLoguser(data.data)
        console.log(value.loguser.name)
        
            if (data.status==='success'){
                value.setIslog(true) 
                localStorage.setItem('log',true)
                navigate('/home')
                    
            }
            else{value.setIslog(false)
            alert("Invalid Email or Password")}
    
    }
    
    
    

    return(

        <div className="container  ">
            
        <div className="width mt-5">
            <input className="form-control mt-3" onChange={(e)=>setReqdata({...reqdata,email:e.target.value})} placeholder=" Enter Your Email"/>
            <input type='password' className="form-control mt-3" onChange={(e)=>setReqdata({...reqdata,password:e.target.value})} placeholder="Enter Your Password"/>
            <button className="btn btn-warning btn-lg col-4 mt-3 text-white" onClick={()=>navigate('/register')}>New User ?</button>
            <button className="btn btn-primary btn-lg   col-4 mt-3" onClick={()=>Check()}>Login</button>

        </div>
        
        </div>
        
        
    )
}

export default Login