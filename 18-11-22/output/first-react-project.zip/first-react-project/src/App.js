
import './App.css';
import Mainroutes from './routes';
import "bootstrap/dist/css/bootstrap.min.css"

function App() {
  return (
    <div className="App">
     <Mainroutes/>
    </div>
  );
}

export default App;
