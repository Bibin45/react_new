import React from 'react'
import './App.css';
import Status from './components/status';
import 'bootstrap/dist/css/bootstrap.min.css';
import List from './components/list';

class App extends React.Component{
  constructor(props){
    super(props)
    this.state={
        postStatus:'',
        totalStatus:[]
      
      }
      
    }


  saveStatus=(e)=>{
    e.preventDefault();
    
     if(this.state.postStatus.trim()){
      let newarr=[this.state.postStatus,...this.state.totalStatus]
      this.setState({
        postStatus:" ",
        totalStatus:newarr,
        
      })
      
     }
     


    }
    
  

  changeStatus=(e)=>{
    return(
      this.setState({
        postStatus:e
      })
    )
  }
  deleteStatus=(e)=>{
   
    let newarr=[...this.state.totalStatus]
    newarr.splice(e,1)
    this.setState({
      totalStatus:newarr
    })
    
  }
    
      
  


    


    render(){

  // console.log(this.state.postStatus)
  // console.log(this.state.totalStatus)

    return (
      
      <div className="App container">
      <Status saveStatus={this.saveStatus}
      changeStatus={this.changeStatus}
      statusValue={this.state.postStatus}
      />
      <List totalStatus={this.state.totalStatus}
      deleteStatus={this.deleteStatus}/>
      </div>
    );
  }
}


export default App;
