
const Status=({saveStatus,changeStatus,statusValue})=>{
    return(
        <>
        <div >
           <h2 className="text-primary mar font  p-3 ">Status Update List</h2>
        <form className="row mar font" >
           <textarea className="form-control col" value={statusValue} onChange={(e)=>changeStatus(e.target.value)} placeholder='Enter Status Here'></textarea>
           {statusValue.trim().length>0? 
           (<button className="btn btn-primary col-2 " type="submit" onClick={saveStatus}>POST STATUS</button>)
           :(null)}
        </form>
        </div>
        </>
    )
}
export default Status