const List=({totalStatus,deleteStatus})=>{
    var datetime = new Date().toDateString()
    console.log(datetime);
    return(
        <div className="font mar">
            {totalStatus.length<1?(
                <h3 className="text-secondary">No Status Updates Are Availabe</h3>
            ):(null)}
            {totalStatus.map((status,index)=>(
                 <div className="row text-white font" key={index}>
                 <h3 className="col-11 card bg-secondary">{status}<span><p className="text">Updated On {datetime}</p></span></h3>
                 
                 <div className="col">
                 <button className="btn btn-warning  text-white " onClick={()=>deleteStatus(index)}>Delete</button>
                 </div>
             </div>
                
            ))}
        </div>
    
    )
}

   

 

export default List