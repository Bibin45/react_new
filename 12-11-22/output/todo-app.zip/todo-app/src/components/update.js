let Update=({updatetask,Changetask,Uptask,Canceltask})=>{
    
    return(<>
    <div className='row'>
          <div className='col'>
            <input value={updatetask.title} onChange={(e)=>(Changetask(e.target.value))} className='form-control bold'/>
          </div>
          <div className='col-auto'>
            <button className='btn btn-success bold' onClick={Uptask}>Update</button>
            <button className='btn btn-warning bold'onClick={Canceltask}>Cancel</button>
          </div>
        </div>
    </>)
}
export default Update