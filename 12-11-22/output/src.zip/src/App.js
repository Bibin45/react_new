import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Addtodo from "./components/add"
import Update from "./components/update"
import Todotask from "./components/todo"
function App() {

// few task 
const[todo,setTodo]=useState([
  {id:1,title:'Mobile',status:false},
  {id:2,title:'Torch',status:false},
])

// temp task

const[newtask,setNewtask]=useState('')
// console.log(newtask)
const[updatetask,setUpdatetask]=useState('')


// add task
let Addtask=()=>{
  if(newtask){
  let a=todo.length+1;
  let myentry={id:a,title:newtask,status:false}
  setTodo([...todo,myentry])
  setNewtask('')
  }
}

// delete task
let DeletTask=(a)=>{
  let Afterdel=todo.filter((todo)=>(todo.id!==a))
  setTodo(Afterdel)
}

// mark task
let MarkTask=(a)=>{
  let Aftermark=todo.map(task=>{if(task.id===a){
    return ({...task,status:!task.status})
  }
  return task
})
setTodo(Aftermark)
}
  


// change task saving values in updatetask
let Changetask=(a)=>{
  let newup={id:updatetask.id,title:a,status:updatetask.status}
  setUpdatetask(newup)
  console.log(updatetask)
}

// cancel update
let Canceltask=()=>{
  setUpdatetask('')
}

// update task  moving to todo
let Uptask=()=>{
  let sortout=[...todo].filter(a=>a.id!==updatetask.id)
  setTodo([...sortout,updatetask])
  setUpdatetask('')
}


  return (
    <div className="container">
      
        <h1 className='text-center text-primary bold'>To-Do List</h1>
        {!updatetask && !updatetask ? 
        (
        <Addtodo 
        newtask={newtask}
        Addtask={Addtask}
        setNewtask={setNewtask}/>
        )
         : 
        (
        <Update 
          updatetask={updatetask}
          Changetask={Changetask}
          Uptask={Uptask}
          Canceltask={Canceltask}/>
        )
        }
        {
          todo && todo.length ? '' : <h6 className='text-center text-success bold'>"No Tasks"</h6>
        }
        <Todotask
        todo={todo}
        MarkTask={MarkTask}
        setUpdatetask={setUpdatetask}
        DeletTask={DeletTask}/>
      </div>
  );
}

export default App;
