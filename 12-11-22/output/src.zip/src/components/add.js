let Addtodo=({newtask,Addtask,setNewtask})=>{
    return(
    <>
    <div className='row'>
            <div className='col'>
              <input className='form-control bold' value={newtask} onChange={(e)=>setNewtask(e.target.value)}/>
              
            </div>
            <div className='col-auto'>
              <button className='btn btn-primary bold'onClick={Addtask}>Add Task</button>
            </div>
          </div>
        <br/>
        </>)
}

export default Addtodo