import 'bootstrap/dist/css/bootstrap.min.css';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faCircleCheck,faPen,faTrashCan} from '@fortawesome/free-solid-svg-icons'


let Todotask=({todo,MarkTask,setUpdatetask,DeletTask})=>{
    return(
        <>
        {todo && todo
        .sort((a,b)=>a.id>b.id?1:-1)
          .map((task,index)=>{
            return(
              
              
                <div className='card mt-3 p-2 border bg-secondary'>
                
                  <div className='row'>
                  <div className='col-8 marl'>
                  <div className={task.status ? 'completed ' : null}>
                  <p className='text-white bold '>{index+1+" , "+task.title}</p>
                  </div>
                  </div>
                  <div className='col-3 '>
                <span className='icon' title='Completed'> <FontAwesomeIcon onClick={()=>MarkTask(task.id)}icon={faCircleCheck}/> </span>
                {!task.status?<span title='Edit'><FontAwesomeIcon className='icon' onClick={()=>setUpdatetask({id:task.id,
                title:task.title,
                status:task.status})} icon={faPen}/></span>:null}
                
                <span className=' icon'title='Delete'><FontAwesomeIcon onClick={()=>DeletTask(task.id)} icon={faTrashCan}/></span>
                
                </div>
                </div>
              </div>
              
            )
          })
        }
        </>
    )
}
export default Todotask