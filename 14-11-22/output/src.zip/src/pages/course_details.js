export default function Coursedetails(){
    return(
      <h1>Courses Details</h1>
    )
  }