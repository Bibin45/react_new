import logo from './logo.svg';
import './App.css';
import React,{useState} from 'react';
import Header from './components/header';
import Footer from './components/footer';
import Courselist from './pages/course_list';
import Coursedetails from './pages/course_details';
import Createcourse from './pages/create_course';
import Home from './pages/home';
import Login from './pages/login';
import Register from './pages/register';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-router'

import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default function Add(){


  //login
  const[myname,setMyname]=useState('')
  const[mypass,setMypass]=useState('')
   

  const[change,setChange]=useState(false)
  console.log(change)
  
  return(
      <Router>
        <div>
          <nav>
            <ul>
              
              <li>
                <Link to="/register">Register</Link>
              </li>
              <li>
                <Link to="/login">LoginPage</Link>
              </li>
              <li>
                <Link to="/home">Home</Link>
              </li>
              <li>
                <Link to="/create">Create Course</Link>
              </li>
              <li>
                <Link to="/list">Course List</Link>
              </li>
              <li>
                <Link to="/details">Course Details</Link>
              </li>
            </ul>
          </nav>
  
          {/* A <Switch> looks through its children <Route>s and
              renders the first one that matches the current URL. */}
          <Switch>
          <Route path="/details">
              <Coursedetails />
            </Route>
          <Route path="/list">
              <Courselist />
            </Route>
          <Route path="/create">
              <Createcourse />
            </Route>
          <Route path="/home">
              <Home />
            </Route>
            <Route path="/register">
              <Register setMyname={setMyname}
              setMypass={setMypass} />
            </Route>
            
            <Route path="/">
              < Login myname={myname}
              mypass={mypass} setChange={setChange}/>
            
            </Route>
          </Switch>
        </div>
      </Router>
  )

}





