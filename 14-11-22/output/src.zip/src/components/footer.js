export default function Footer(){
    return(
        <>
    <footer class="container-fluid bg-dark mt-5 text-center text-white">
        
        <h2>Footer</h2>
    </footer>
        </>
    )
}