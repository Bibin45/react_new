export default function Header(){



    return(
    <>
    <nav className="navbar bg-secondary navbar-default">
  <div className="container">
    <div className="navbar-header">
      
      <a className="navbar-brand" href="#">Me</a>
    </div>
    <div className="collapse navbar-collapse" id="myNavbar">
      <ul className="nav navbar-nav navbar-right">
        <li><a href="#">WHO</a></li>
        <li><a href="#">WHAT</a></li>
        <li><a href="#">WHERE</a></li>
      </ul>
    </div>
  </div>
</nav>
<div className="container-fluid  bg-secondary text-center">
  <h3 className="margin">Who Am I?</h3>
  <h3>I'm an adventurer</h3>
</div>
    </>
    )
}