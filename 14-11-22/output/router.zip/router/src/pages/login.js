
  import React,{useState} from 'react';
  import 'react-router'
  import { useHistory } from 'react-router-dom';
  
  



export default function Login({myname,mypass,setChange}) {
    const[user,setUser]=useState('')
    const[pw,setPassword]=useState('')
      console.log(user)
      console.log(pw)

    

      const history=useHistory()
    let data={
        request:'candidate_login',
        email:'jegan',
        password:1234567890

    }
      const Validate=()=>{
        if(myname===user&&mypass===pw){
            alert('success')
            history.push({pathname:'/home',a:setChange(true)})
            fetch('http://karka.academy/api/action.php',{method:'POST',body:JSON.stringify(data)}).then((data)=>data.json()).then((response)=>console.log(response))
            
        }
        else{
            alert("Incorrect Username or Password")
        }
    }

    return(
        <>
        <div className="text-center container">
         <div className="col-auto">
         <h2>This is Login Page</h2>
        <h1 className="h3 mb-3 font-weight-normal">Please sign in</h1>
        
        <input className="form-control" onChange={(e)=>setUser(e.target.value)} placeholder="Email address"/>
        
        <input className="form-control"  onChange={(e)=>setPassword(e.target.value)}  placeholder="Password" />
        <button className="btn btn-lg btn-primary btn-block" onClick={()=>Validate()} type="submit">Log in</button>
        </div>
        </div>
        

        </>
        )
        }







