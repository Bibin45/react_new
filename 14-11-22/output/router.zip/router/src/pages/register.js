import React,{useState} from 'react';
import { useHistory } from 'react-router-dom';

export default function Register({setMyname,setMypass}) {
    const[regn,setRegn]=useState('')
    const[regp,setRegp]=useState('')
    const history=useHistory()
    const Validate_reg=()=>{
        setMyname(regn)
        setMypass(regp)
        history.push('/login')
    }

    return(
         <div >
    <h2>This is Register Page</h2>
    <label>Name</label>
    <input onChange={(e)=>setRegn(e.target.value)} className="form-control" />
    <label>Mobile</label>
    <input className="form-control"/>
    <label>Password</label>
    <input className="form-control" onChange={(e)=>setRegp(e.target.value)}  />
    <button className='btn btn-primary' onClick={()=>Validate_reg()}>Register</button>
    </div>);
  }