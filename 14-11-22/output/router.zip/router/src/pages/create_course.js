export default function Createcourse(){
    return(
      <h1>Courses Will be created</h1>
    )
  }