export default function Courselist(){
    return(
      <h1>Courses List</h1>
    )
  }